
package utilidades.Verificador;


public enum TipoValidacion {
    NO_NULO,
    NUMERICO,
    CADENA_TEXTO_VALIDA
}